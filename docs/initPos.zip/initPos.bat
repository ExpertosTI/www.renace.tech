<# :
@echo off
setlocal
title Buscador de POSAgent
echo Buscando aplicaciones que inicien con "POS"...
echo Por favor espera...

:: Ejecuta el codigo PowerShell incrustado abajo
powershell -noprofile -executionpolicy bypass "iex (${%~f0} | out-string)"
goto :EOF
: #>

# --- INICIO DEL SCRIPT POWERSHELL ---
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# 1. Definir carpeta de destino (Startup)
$StartupFolder = [Environment]::GetFolderPath("Startup")

# 2. Crear la Ventana
$form = New-Object System.Windows.Forms.Form
$form.Text = "Instalador de Inicio Automatico"
$form.Size = New-Object System.Drawing.Size(400, 450)
$form.StartPosition = "CenterScreen"
$form.FormBorderStyle = "FixedDialog"
$form.MaximizeBox = $false

# 3. Etiqueta
$label = New-Object System.Windows.Forms.Label
$label.Location = New-Object System.Drawing.Point(10, 15)
$label.Size = New-Object System.Drawing.Size(360, 20)
$label.Text = "Se encontraron estos programas POS. Selecciona uno:"
$form.Controls.Add($label)

# 4. Lista (ListBox)
$listBox = New-Object System.Windows.Forms.ListBox
$listBox.Location = New-Object System.Drawing.Point(10, 40)
$listBox.Size = New-Object System.Drawing.Size(360, 300)
$listBox.Sorted = $true
$form.Controls.Add($listBox)

# 5. Boton Guardar
$btnOk = New-Object System.Windows.Forms.Button
$btnOk.Location = New-Object System.Drawing.Point(200, 360)
$btnOk.Size = New-Object System.Drawing.Size(170, 40)
$btnOk.Text = "Hacer que inicie con Windows"
$btnOk.DialogResult = [System.Windows.Forms.DialogResult]::OK
$form.Controls.Add($btnOk)

# 6. Boton Cancelar
$btnCancel = New-Object System.Windows.Forms.Button
$btnCancel.Location = New-Object System.Drawing.Point(10, 360)
$btnCancel.Size = New-Object System.Drawing.Size(100, 40)
$btnCancel.Text = "Salir"
$btnCancel.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
$form.Controls.Add($btnCancel)

# 7. BUSQUEDA CON FILTRO "POS*"
$programs = @{}
$paths = @(
    [Environment]::GetFolderPath("StartMenu"),       # Menu usuario actual
    [Environment]::GetFolderPath("CommonStartMenu")  # Menu todos los usuarios
)

$foundCount = 0

foreach ($path in $paths) {
    if (Test-Path $path) {
        $shortcuts = Get-ChildItem -Path $path -Recurse -Include *.lnk -ErrorAction SilentlyContinue
        foreach ($lnk in $shortcuts) {
            $name = $lnk.BaseName
            
            # --- AQUI ESTA EL FILTRO ---
            # -like "POS*" significa que debe empezar con POS
            if ($name -like "POS*") {
                if (-not $programs.ContainsKey($name)) {
                    $programs[$name] = $lnk.FullName
                    $listBox.Items.Add($name) | Out-Null
                    $foundCount++
                }
            }
        }
    }
}

# Si no encuentra nada, avisa y cierra
if ($foundCount -eq 0) {
    [System.Windows.Forms.MessageBox]::Show("No se encontraron programas instalados que empiecen con 'POS'. Verifique que el software este instalado.", "No encontrado", "OK", "Warning")
    $form.Close()
} else {
    # Seleccionar el primero por defecto para facilitar
    $listBox.SelectedIndex = 0
    
    # Mostrar ventana
    $result = $form.ShowDialog()

    if ($result -eq "OK") {
        $selectedName = $listBox.SelectedItem
        if ($selectedName) {
            $sourceLnk = $programs[$selectedName]
            $destLnk = Join-Path -Path $StartupFolder -ChildPath "$selectedName.lnk"
            
            try {
                Copy-Item -Path $sourceLnk -Destination $destLnk -Force
                [System.Windows.Forms.MessageBox]::Show("Configurado Correctamente!`n`nEl programa '$selectedName' iniciara automaticamente la proxima vez que enciendas la PC.", "Exito", "OK", "Information")
            }
            catch {
                [System.Windows.Forms.MessageBox]::Show("Ocurrio un error al configurar: $_", "Error", "OK", "Error")
            }
        }
    }
}